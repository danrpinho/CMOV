package com.example.acmemarket_client.model;

public class Voucher {
    boolean used;
    int id;

    public boolean isUsed() {
        return used;
    }

    public int getId() {
        return id;
    }
}
