package com.example.acmemarket_client.model.NetworkLayer.NetworkLayerModels;

public class ErrorBody {
    String message;

    public String getMessage() {
        return message;
    }
}
