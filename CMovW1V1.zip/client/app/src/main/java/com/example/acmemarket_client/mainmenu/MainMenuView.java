package com.example.acmemarket_client.mainmenu;

public interface MainMenuView {
    void showMessage(String message);

    void saveCart();
}
