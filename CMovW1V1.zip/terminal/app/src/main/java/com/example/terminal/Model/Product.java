package com.example.terminal.Model;

public class Product {

    String uuid;
    float price;
}
