package com.example.terminal.main;

public interface MainView {

    void showMessage(String message);
}
