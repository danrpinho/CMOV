package com.example.terminal.Model;

public class ServerResponse {
    String message;

    public String getMessage() {
        return message;
    }
}
