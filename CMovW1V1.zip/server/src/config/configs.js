module.exports = {
    JWT_SECRET: 'top_secret',
};
